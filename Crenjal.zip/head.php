<base href="//localhost/Crenjal/" />
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<meta HTTP-EQUIV="CONTENT-LANGUAGE" CONTENT="fa-ir"/>
<meta NAME="AUTHOR" CONTENT="jamal zareie جمال زارعی"/>
<meta NAME="COPYRIGHT" CONTENT="2016 www.crenjal.com"/>
<meta NAME="ROBOTS" CONTENT="ALL"/>
<link href="img/logo-crenjal.ICO" rel="shortcut icon" type="image/x-icon">
