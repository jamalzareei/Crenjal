<?php session_start(); ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <?php include_once './head.php'; ?>
        <title> کرنجال| معرفی محصولات و اخبار کرنجال</title>
        <meta NAME="DESCRIPTION" CONTENT="معرفی و اخبار مربوط به محصولات صنایع دستی کرنجال"/>
        <meta NAME="KEYWORDS" CONTENT="کرنجال،معرفی،اخبار،معرفی محصولات، اخبار محصولات"/>
    </head>
    <body>
        <div class="container-fluid">
            <?php
            // put your code here
            include './header.php';
            ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="row product">

                        <div class="col-md-9">

                            <div class="tabbable" id="tabs-689295"> <!-- Only required for left/right tabs -->
                                <ul class="nav nav-tabs" style="width: 200px;margin: auto">
                                    <li class="" style="width: 50%"><a aria-expanded="false" href="#panel-647047" data-toggle="tab">معرفی</a></li>
                                    <li class="active" style="width: 50%"><a aria-expanded="true" href="#panel-589036" data-toggle="tab">خبر</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="panel-589036">
                                        <?php
                                        $table = "cr_intro_news";
                                        $fields = "*";
                                        $where_news = "id>'0' and news_intro='خبر'"; // and news_intro='خبر'
                                        $order = "id DESC";
                                        $limit = "0,10";
                                        $news = $dbclass->select($table, $fields, $where_news, $order, $limit);
                                        if (is_array($news)) {
                                            foreach ($news as $row_news) {
                                                ?>
                                                <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-lg-2 pull-right text-center">
                                                            <img alt="<?php echo $row_intro["title"]; ?>" src="upload/240_238/<?php echo $row_news["photo"]; ?>" width="100" height="100" class="img-circle" />
                                                        </div>
                                                        <div class="col-lg-10 pull-right">
                                                            <div class="row">
                                                                <div class="col-xs-12 text-right">
                                                                    <a title="<?php echo $row_intro["title"]; ?>" href="news/<?php echo $row_news["id"] . "/" . str_replace(" ", "-", $row_news["title"]); ?>">
                                                                        <h2>
                                                                            <?php echo $row_news["title"]; ?>
                                                                        </h2>
                                                                    </a>
                                                                </div>
                                                                <div class="col-xs-6 text-right pull-right">
                                                                    <span class="label label-info" dir="rtl"><i class="glyphicon glyphicon-calendar"></i> <?php echo $row_news["date"]; ?></span>
                                                                    <!--<span class="label label-success"><i class="glyphicon glyphicon-comment"></i>   کامنت</span>-->
                                                                    <span class="label label-danger" dir="rtl"><i class="glyphicon glyphicon-eye-open"></i>   تعداد بازدید<?php echo $row_news["viewer"]; ?></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-xs-2 pull-right text-center"><br>
                                                            <button type="button" class="btn btn-add-product">ادامه مطلب</button>
                                                        </div>
                                                        <div class="col-xs-9 text-right" style="border-bottom: 1px solid;margin:0 20px 20px">                            
                                                            <blockquote class="pull-right">
                                                                <p dir="rtl"><?php echo $row_news["summery"]; ?> ...</p>                                                            
                                                            </blockquote>
                                                            
                                                            <br><br>
                                                        </div>
                                                    </div>
                                                </div>

                                                <hr>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                    <div class="tab-pane" id="panel-647047">
                                        <?php
                                        $where_intro = "id>'0' and news_intro='معرفی'"; // 
                                        $intro = $dbclass->select($table, $fields, $where_intro, $order, $limit);
                                        if (is_array($intro)) {
                                            foreach ($intro as $row_intro) {
                                                ?>
                                                <div class="col-xs-12">
                                                    <div class="row">
                                                        <div class="col-lg-2 pull-right">
                                                            <img alt="<?php echo $row_intro["title"]; ?>" src="upload/240_238/<?php echo $row_intro["photo"]; ?>" width="100" height="100" class="img-circle" />
                                                        </div>
                                                        <div class="col-lg-10 pull-right">
                                                            <div class="row">
                                                                <div class="col-xs-12 text-right">
                                                                    <a title="<?php echo $row_intro["title"]; ?>" href="intro/<?php echo $row_intro["id"] . "/" . str_replace(" ", "-", $row_intro["title"]); ?>">
                                                                        <h2>
                                                                            <?php echo $row_intro["title"]; ?>
                                                                        </h2>
                                                                    </a>
                                                                </div>
                                                                <div class="col-xs-12 text-right pull-right">
                                                                    <span class="label label-info" dir="rtl"><i class="glyphicon glyphicon-calendar"></i> <?php echo $row_news["date"]; ?></span>
                                                                    <!--<span class="label label-success"><i class="glyphicon glyphicon-comment"></i>   کامنت</span>-->
                                                                    <span class="label label-danger" dir="rtl"><i class="glyphicon glyphicon-eye-open"></i>   تعداد بازدید<?php echo $row_news["viewer"]; ?></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-xs-2 pull-right text-center"></div>
                                                        <div class="col-xs-10 text-right" style="border-bottom: 1px solid;margin:0 20px 20px">                            
                                                            <blockquote class="pull-right">
                                                                <p><?php echo $row_intro["summery"]; ?></p>
                                                            </blockquote>

                                                        </div>
                                                    </div>
                                                </div>

                                                <hr>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title">پر بازدیدترین</h3>
                                </div>
                                <div class="panel-body">
                                    <?php
                                    $where_viewer = "id>'0'"; // and news_intro='خبر'
                                    $order_viewer = "viewer DESC";
                                    $limit_viewer = "0,5";
                                    $news_viewer = $dbclass->select($table, $fields, $where_viewer, $order_viewer, $limit_viewer);
                                    if (is_array($news_viewer)) {
                                        foreach ($news_viewer as $value_viewer) {
                                            ?>
                                    <a title="<?php echo $value_viewer["title"]; ?>" class="" href="intro/<?php echo $value_viewer["id"] . "/" . str_replace(" ", "-", $value_viewer["title"]); ?>">
                                                <div class="row margin-news">
                                                    <div class="col-xs-1 pull-right"></div>
                                                    <div class="col-xs-2 pull-right">
                                                        <img alt="<?php echo $value_viewer["title"]; ?>" class="img-circle" src="upload/50_50/<?php echo $value_viewer["photo"]; ?>"/>
                                                    </div>
                                                    <div class="col-xs-8 pull-right text-right">
                                                        <h4><strong><?php echo $value_viewer["title"]; ?></strong></h4>
                                                    </div>
                                                </div>
                                            </a>
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title">منتخب سردبیر</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-1 pull-right"></div>
                                        <div class="col-xs-2 pull-right">
                                            <img src="upload/50_50/crenjal_com-05-01-1395-05-09-53-Capture1.JPG"/>
                                        </div>
                                        <div class="col-xs-8 pull-right text-right">
                                            <h4><strong>jamal</strong></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>


                </div>
            </div>
        </div>
        <hr>
        <?php
// put your code here
        include './footer.php';
        ?>

    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
