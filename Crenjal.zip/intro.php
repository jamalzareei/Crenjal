<?php
session_start();
include_once './DB/db_con.php';
$id = "";
if (isset($_GET["id"])) {
    $id = $_GET["id"];
} else {
    $id = "";
    header("location: news");
}

$table = "cr_intro_news";
$fields = "*";
$where = "id='$id'";
$order = "id";
$limit = "1";
$select = $dbclass->select_one($table, $fields, $where, $order, $limit);

$view = $select["viewer"] + 2;
$set = "viewer='$view'";
$where_update = "id='$id'";
$updat = $dbclass->update($table, $set, $where_update);

$code_intro_news=$select["code_intro_news"];
$table_comment = "cr_comment_intro_news";
$fields_comment = "*";
$where_comment = "code_intro_news='$code_intro_news' and ans_id_comment='0'";
$order_comment = "id_comment DESC";
$limit_comment = "0,15";
$produc_comment = $dbclass->select($table_comment, $fields_comment, $where_comment, $order_comment, $limit_comment);
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <?php include_once './head.php'; ?>
        <title> کرنجال| <?php echo $select["title"]; ?></title>
        <meta NAME="DESCRIPTION" CONTENT="<?php echo $select["summery"]; ?>"/>
        <meta NAME="KEYWORDS" CONTENT="کرنجال،<?php echo $select["title"]; ?>،<?php echo $select["news_intro"]; ?> <?php echo $select["title"]; ?>"/>
    </head>
    <body>
        <div class="container-fluid">
            <?php
            // put your code here
            include './header.php';
            ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="row product">

                        <div class="col-xs-12 col-lg-2 pull-right"></div>
                        <div class="col-xs-12 col-lg-1 pull-right">
                            <div class="row">
                                <div class="col-lg-12 scrolltop text-center">
                                    <li class="glyphicon glyphicon-chevron-up font-sizing"></li> 
                                </div>
                                <div class="col-lg-12 img-small-product">
                                    <?php
                                    //$code_intro_news = $select["code_intro_news"];
                                    $table_gallery = "cr_gallery_intro_news";
                                    $fields_gallery = "*";
                                    $where_gallery = "code_intro_news='$code_intro_news'";
                                    $order_gallery = "id_gallery";
                                    $limit_gallery = "100";
                                    $select_gallery = $dbclass->select($table_gallery, $fields_gallery, $where_gallery, $order_gallery, $limit_gallery);
                                    if (is_array($select_gallery)) {
                                        foreach ($select_gallery as $value) {
                                            echo '<a title="' . $value["title"] . '" id="modal-970313-crenjal" href="#modal-container-970313-crenjal" role="button" class="btn" data-toggle="modal">'
                                            . '<img alt="' . $value["title"] . '" src="upload/74_74/' . $value["photo_gallery"] . '" width="100%"/>'
                                            . '</a>';
                                        }
                                    }
                                    ?>
                                    <div class="modal fade in" id="modal-container-970313-crenjal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                        <div class="modal img-modal fade in" id="modal-container-970313-crenjal">
                                            <div class="modal-dialog modal-lg" id="modal-images">
                                                <div class="modal-content">
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-8 modal-image">
                                                                <?php
                                                                echo '
                                                                        <img class="img-responsive" src="upload/1349_790/' . $select["photo"] . '">
                                                                        ';
                                                                if (is_array($select_gallery)) {
                                                                    foreach ($select_gallery as $row_gallery) {
                                                                        echo '
                                                                                <img class="img-responsive hidden" src="upload/1349_790/' . $row_gallery["photo_gallery"] . '">
                                                                                ';
                                                                    }
                                                                }
                                                                ?>
                                                                <a href="" class="img-modal-btn left"><i class="glyphicon glyphicon-chevron-left"></i></a>
                                                                <a href="" class="img-modal-btn right"><i class="glyphicon glyphicon-chevron-right"></i></a>
                                                            </div>
                                                            <div class="col-md-4 modal-meta">
                                                                <div class="modal-meta-top">
                                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                    <br>
                                                                    <div class="img-poster clearfix text-right">
                                                                        <a href="intro/<?php echo $select["id"] . "/" . str_replace(" ", "-", $select["title"]); ?>">
                                                                            <img class="img-circle pull-right" src="upload/74_74/<?php echo $select["photo"]; ?>"/>
                                                                        </a>
                                                                        <h3>
                                                                            <strong>
                                                                                <a style="margin-right: 3%;" href="intro/<?php echo $select["id"] . "/" . str_replace(" ", "-", $select["title"]); ?>">
                                                                                    <?php echo $select["title"]; ?>
                                                                                </a>
                                                                            </strong>
                                                                        </h3>
                                                                        <span>
                                                                            <div class="col-lg-8 col-xs-8 pull-right help-block">
                                                                                <small><?php echo $select["date"]; ?></small>                                                                                    
                                                                            </div>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-meta-bottom">                                                                    
                                                                    <ul class="img-comment-list">
                                                                        <?php
                                                                        if (is_array($produc_comment)) {
                                                                            foreach ($produc_comment as $row_comment) {
                                                                                echo '
                                                                                        <li class="row">
                                                                                            <div class="comment-img pull-right col-xs-2">
                                                                                                <img src="img/logo.jpg">
                                                                                            </div>
                                                                                            <div class="comment-text pull-right text-right col-xs-10">
                                                                                                <strong><a href="">' . $row_comment["name_user"] . '</a></strong>
                                                                                                <span class="date sub-text">' . $row_comment["date_comment"] . '</span>
                                                                                                <p dir="rtl" style="text-align: justify;">' . $row_comment["comment"] . '</p> 
                                                                                            </div>
                                                                                        </li>
                                                                                        ';
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </ul>   
                                                                <!--<input type="text" class="form-control" placeholder="Leave a commment.."/>-->
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><!-- /.modal-content -->
                                            </div><!-- /.modal-dialog -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 scrollbottom text-center">
                                    <li class="glyphicon glyphicon-chevron-down font-sizing"></li>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-lg-7 pull-right">
                            <div class="text-right">

                                <h1 class="text-right"><?php echo $select["title"]; ?> <i class="glyphicon glyphicon-bookmark"></i> </h1>
                            </div>
                            <br>
                            <div class="col-xs-6 text-right pull-right">
                                <span class="label label-info" dir="rtl"><i class="glyphicon glyphicon-calendar"></i>&nbsp;&nbsp; <?php echo $select["date"]; ?></span>
                                <span class="label label-success" dir="rtl"><i class="glyphicon glyphicon-comment"></i>&nbsp;&nbsp;    کامنت&nbsp;&nbsp;<?php echo count($produc_comment); ?></span>
                                <span class="label label-danger" dir="rtl"><i class="glyphicon glyphicon-eye-open"></i>&nbsp;&nbsp;   تعداد بازدید&nbsp;&nbsp;<?php echo $select["viewer"]; ?></span>
                            </div>
                            <div class="col-xs-6 text-left pull-right">                                
                                <div title="" data-original-title="" class="col-sm-3 pull-left text-center menu-bar-sosial menu-bar-facebook">
                                    <a title=" facebook crenjal" data-original-title="" href=""><span title="" data-original-title="" class="menu-facebook"></span></a>
                                </div>
                                <div title="" data-original-title="" class="col-sm-3 pull-left text-center menu-bar-sosial menu-bar-instagram">
                                    <a title="instagram crenjal" data-original-title="" href=""><span title="" data-original-title="" class="menu-instagram"></span></a>
                                </div>
                                <div title="" data-original-title="" class="col-sm-3 pull-left text-center menu-bar-sosial menu-bar-telegram">
                                    <a title="telegram crenjal" data-original-title="" href=""><span title="" data-original-title="" class="menu-telegram"></span></a>
                                </div>
                                <div title="" data-original-title="" class="col-sm-3 pull-left text-center menu-bar-sosial menu-bar-google+">
                                    <a title="google+ crenjal" data-original-title="" href=""><span title="" data-original-title="" class="menu-google"></span></a>
                                </div>
                            </div><br><br>
                            <div class="text-center">
                                <img alt="<?php echo $select["titile"]; ?>" class="img-thumbnail" alt="Bootstrap Image Preview" src="upload/<?php echo $select["photo"]; ?>">
                            </div>
                            <div class="text-right text-muted" dir="rtl">
                                <?php echo $select["message"]; ?>                                
                            </div>

                        </div>
                        <div class="col-xs-12 col-lg-2 pull-right"></div>
                    </div>
                    <div class="row product">
                        <div class="col-xs-12 col-lg-2 pull-right"></div>
                        <div class="col-xs-12 col-lg-1 pull-right"></div>
                        <div class="col-xs-12 col-lg-9 pull-right">
                            <div class="panel-body">
                                <div class="row insert-comment">
                                    <?php
                                    if (isset($_COOKIE["email"])) {
                                        ?>
                                        <form class="form-horizontal">
                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-sm-2 control-label"></label>
                                                <div class="col-sm-8">
                                                    <textarea class="form-control" id="txt-comment"></textarea>
                                                </div>
                                                <label for="inputEmail3" class="col-sm-2 control-label"></label>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-offset-2 col-sm-10">
                                                    <button type="button" class="btn btn-default" onclick="comment_intro_news('<?php echo $code_intro_news; ?>', '0')">ثبت نظر</button>
                                                </div>
                                            </div>
                                        </form>
                                    <?php } ?>
                                </div>
                                <div class="comment-append">

                                </div>
                                <?php
                                if (is_array($produc_comment)) {
                                    foreach ($produc_comment as $row_comment) {
                                        echo '<div class="row comments">
                                                <div class="col-xs-2 pull-right text-center">
                                                    <i class="glyphicon glyphicon-user" style="font-size:50px"></i>
                                                    
                                                    <p>
                                                    <div class="text-center btn user-comment">
                                                        ' . $row_comment["name_user"] . '
                                                    </div>
                                                    </p>
                                                </div>
                                                <div class="col-xs-8 coment pull-right">
                                                    <div class="row">
                                                        <div class="col-xs-12 pull-right">
                                                            <div class="row">
                                                                <div class="col-xs-6 pull-left text-left">

                                                                </div>
                                                                <div class="col-xs-6 pull-right text-right date-comment">
                                                                    ' . $row_comment["date_comment"] . '
                                                                </div>
                                                            </div>
                                                            <p dir="rtl">
                                                                ' . $row_comment["comment"] . '
                                                            </p>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-xs-4 pull-left text-left">
                                                                <button type="button" class="btn btn-add-product" onclick="add_comment_zir_intro_news(\'' . $row_comment["id_comment"] . '\',\'' . $code_intro_news . '\')">پاسخ به این پرسش</button>
                                                            </div>
                                                            <div class="col-xs-8 pull-right text-right date-comment">

                                                            </div>
                                                        </div>
                                                        
                                                    <div id="' . $row_comment["id_comment"] . '"></div>
                                                    ';
                                        $id_comm = $row_comment["id_comment"];
                                        $table_comment_zir = "cr_comment_intro_news";
                                        $fields_comment_zir = "*";
                                        $where_comment_zir = "code_intro_news='$code_intro_news' and ans_id_comment='$id_comm'";
                                        $order_comment_zir = "id_comment";
                                        $limit_comment_zir = "0,15";
                                        $produc_comment_zir = $dbclass->select($table_comment_zir, $fields_comment_zir, $where_comment_zir, $order_comment_zir, $limit_comment_zir);
                                        if (is_array($produc_comment_zir)) {
                                            foreach ($produc_comment_zir as $row_comment_zir) {

                                                echo '<hr><div class="row">
                                                                    <div class="col-xs-1 pull-right"></div>
                                                                    <div class="col-xs-2 pull-right text-center btn">
                                                                    ' . $row_comment_zir["name_user"] . '
                                                                    </div>
                                                                    <div class="col-xs-7 pull-right text-right">
                                                                        <div class="row">
                                                                            <div class="col-xs-6 pull-left text-left">

                                                                            </div>
                                                                            <div class="col-xs-6 pull-right text-left date-comment help-block">
                                                                                <small>' . $row_comment_zir["date_comment"] . '</small>
                                                                            </div>
                                                                        </div>
                                                                        <p dir="rtl">
                                                                            ' . $row_comment_zir["comment"] . '
                                                                        </p>
                                                                    </div>
                                                                </div>';
                                            }
                                        }

                                        echo '</div>
                                                </div>
                                                <div class="col-xs-2 pull-right"></div>
                                            </div><hr>';
                                    }
                                }
                                else {
                                    echo '
                                                <div class="row one-search empty-buy">
                                                هیچ نظری ثبت نگردیده است، 
                                                اولین نفری باشید که نظر خود را وارد میکنید
                                            </div>
                                                ';
                                }
                                ?>
                            </div>
                        </div>
                        <div class="col-xs-12 col-lg-2 pull-right"></div>
                    </div>
                </div>
            </div>
            <hr>
            <?php
            // put your code here
            include './footer.php';
            ?>

        </div>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
