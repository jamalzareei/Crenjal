<?php ?>
<div class="row color-footer">
    <div class="col-md-1 float-992-right"></div>
    <div class="col-md-3 float-992-right">
        <br><hr>
        <div class="row text-right row-footer"><label> یزد، صفاییه، بلوار دانشگاه، جنب املاک کاخ</label> :نشانی</div>
        <div class="row text-right row-footer"><label> 035 - 38 25 1666</label> :تلفن</div>
        <div class="row text-right row-footer"><label> 0921 - 544 3586</label> :موبایل</div>
        <div class="row text-right row-footer"><label> Info@crenjal.com </label> :ایمیل</div>
        <br>
    </div>
    <div class="col-md-3 float-992-right">
        <br><hr>
        <a title="درباره کرنجال" href="#"><div class="row text-right row-footer">درباره کرنجال</div></a>
        <a title="تماس با کرنجال" href="connect-us"><div class="row text-right row-footer">تماس با کرنجال</div></a>
        <a title="همکاری با کرنجال" href="employ"><div class="row text-right row-footer">همکاری با کرنجال</div></a>
        <a title="سوالات متداول در کرنجال" href="#"><div class="row text-right row-footer">سوالات متداول</div></a>
        <br>
    </div>
    <div class="col-md-5 float-992-right">
        <div class="row brands">
            <div class="col-xs-3 col-md-3 col-sm-2"></div>
            <div class="col-xs-3 col-md-3 col-sm-2"></div>
            <div class="col-xs-3 col-md-3 col-sm-2"></div>
            <div class="col-xs-3 col-md-3 col-sm-2"></div>
        </div>
        
    </div>
</div>
<div class="row text-center copy-right" >
    .تمامی حقوق این وب سایت مربوط به گروه کرنجال است
    <br>
    .استفاده از مطالب این وب سایت فقط برای استفاده غیر تجاری و با ذکر منبع بلامانع می باشد<br>
   
<div class="row hr-black"></div>
    copyright ©2016 CRENJAL.COM - Design by Crenjal-Group
</div>