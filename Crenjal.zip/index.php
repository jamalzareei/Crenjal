<?php
session_start();
include_once './DB/db_con.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include_once './head.php'; ?>
        <title>فروشگاه صنایع دستی کرنجال</title>
        <meta NAME="DESCRIPTION" CONTENT="سایت اینترنتی فروش صنایع دستی کرنجال"/>
        <meta NAME="KEYWORDS" CONTENT="کرنجال،صنایع دستی،فروشگاه اینترنتی،فروشگاه اینترنتی کرنجال،فروشگاه کرنجال"/>
    </head>
    <body>
        <div class="container-fluid">
            <?php
            // put your code here
            include './header.php';
            ?>
            <div class="row">
                <div class="carousel slide" id="carousel-413833">

                    <div class="carousel-inner" onmouseover="sliders_on()" onmouseout="sliders_off()" id="load_main_slider">
                        <?php
                        $table_slide = "cr_product";
                        $fields_slide = "*";
                        $where_slide = "id_product>'0'";
                        $order_slide = "id_product DESC";
                        $limit_slide = "0,1";
                        $products_slide = $dbclass->select($table_slide, $fields_slide, $where_slide, $order_slide, $limit_slide);
                        if (is_array($products_slide)) {
                            foreach ($products_slide as $row_slide) {
                                echo '
                                    <div class="item active">
                                        <img id="id_slider" class="1" alt="' . $row_slide["name_product_fa"] . '" src="upload/' . $row_slide["photo_product"] . '" height="555px" width="100%">
                                        <div class="carousel-caption">
                                            <h1 class="font-size-zero">فروشگاه صنایع دستی کرنجال</h1>
                                            <h4>' . $row_slide["name_product_fa"] . '</h4>
                                            <h4>' . $row_slide["name_product_en"] . '</h4>
                                        </div>
                                    </div>
                                    ';
                            }
                        }
                        ?>
                        <!--<div class="item active">
                            <img alt="Carousel Bootstrap First" src="upload/1349_790/" height="600px" width="100%">
                            <div class="carousel-caption">
                                <h4>جمال جمال جمال جمال جمال </h4>
                                <p>جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمالجمال جمال جمال جمال 
                                    جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال </p>
                            </div>
                        </div>
                        <div class="item">
                            <img alt="Carousel Bootstrap Second" src="img/slide04.jpg" height="600px" width="100%">
                            <div class="carousel-caption">
                                <h4>جمال جمال جمال جمال جمال </h4>
                                <p>جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمالجمال جمال جمال جمال 
                                    جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال </p>
                            </div>
                        </div>
                        <div class="item">
                            <img alt="Carousel Bootstrap Third" src="img/slide04.jpg" height="600px" width="100%">
                            <div class="carousel-caption">
                                <h4>جمال جمال جمال جمال جمال </h4>
                                <p>جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمالجمال جمال جمال جمال 
                                    جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال جمال </p>
                            </div>
                        </div>-->
                    </div>

                    <a title="فروشگاه اینترنتی کرنجال" class="left carousel-control" href="#carousel-413833" data-slide="prev" onmouseover="sliders_on()" onmouseout="sliders_off()" onclick="slider(1)" id="left_slide">
                        <i class="slide-show-left glyphicon glyphicon-chevron-left" onmouseover="sliders_on()" onmouseout="sliders_off()"></i>
                    </a>
                    <a title="فروشگاه اینترنتی کرنجال" class="right carousel-control" href="#carousel-413833" data-slide="next" onmouseover="sliders_on()" onmouseout="sliders_off()" onclick="slider(1)" id="right_slide">
                        <i class="slide-show-right glyphicon glyphicon-chevron-right" onmouseover="sliders_on()" onmouseout="sliders_off()"></i>
                    </a>
                </div>	
            </div>
            <br>
            <div class="row blue-info">
                جدیدترن محصولات 
            </div>
            <div id="load-new-product-index" class="row text-center load-new-product-index" onscroll="">
                <img src="img/Jumping letters.gif" alt="load-crenjal" height="42" width="140" alt="فروشگاه صنایع دستی کرنجال" />
                <br>
                <button class="btn btn-group-sm btn-danger" type="button" onclick="load_new_product_index()">جدیدترین محصولات</button>
                <?php //include_once './_php/load_new_product_index.php'; ?>
            </div>
            <?php //include_once './new_product.php'; ?>

            <div class="row">
                <div class="row">
                    <div class="col-md-4">
                        <div class="thumbnail view-third">
                            <img alt="فروشگاه صنایع دستی کرنجال" src="img/crenjal/mr.JPG" width="100%">
                            <div class="mask">  
                                <a title="فروشگاه صنایع دستی کرنجال محصولات ویژه آقایان" href="products/#/sex1_1-mr">
                                    <h2>ویژه آقایان</h2>  
                                    <div class="caption">
                                        <p>Your Text</p>
                                        <!--<h3>Thumbnail label</h3>-->
                                        <p>تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست 
                                            تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست 
                                            تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست </p>
                                        <p><a title="فروشگاه صنایع دستی کرنجال محصولات ویژه آقایان" class="btn btn-primary" href="products/#/sex1_1-mr">دیدن محصولات آقایان</a></p>
                                    </div>
                                    <h2></h2>  
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="thumbnail view-third">
                            <img alt="فروشگاه صنایع دستی کرنجال محصولات ویژه بانوان" src="img/crenjal/mis.JPG" width="100%">
                            <div class="mask">  

                                <a title="فروشگاه صنایع دستی کرنجال محصولات ویژه بانوان" href="products/#/sex2_1-mis">
                                    <h2>ویژه بانوان</h2>  
                                    <div class="caption">
                                        <p>Your Text</p>
                                        <!--<h3>Thumbnail label</h3>-->
                                        <p>تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست 
                                            تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست 
                                            تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست </p>
                                        <p><a title="فروشگاه صنایع دستی کرنجال محصولات ویژه بانوان" class="btn btn-primary" href="products/#/sex2_1-mis">دیدن محصولات بانوان</a></p>
                                    </div>
                                    <h2></h2>   
                                </a>
                            </div>  
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="thumbnail view-third">
                            <img alt="فروشگاه صنایع دستی کرنجال محصولات ویژه"  src="img/crenjal/vizhe.JPG" width="100%">
                            <div class="mask">  

                                <a title="فروشگاه صنایع دستی کرنجال محصولات ویژه" href="products/#/vizhe_1">
                                    <h2>محصولات ویژه</h2>  
                                    <div class="caption">
                                        <p>Your Text</p>
                                        <!--<h3>Thumbnail label</h3>-->
                                        <p>تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست 
                                            تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست 
                                            تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست تست </p>
                                        <p><a title="فروشگاه صنایع دستی کرنجال محصولات ویژه" class="btn btn-primary" href="products/#/vizhe_1">دیدن محصولات ویژه</a></p>
                                    </div>
                                    <h2></h2>  
                                </a>
                            </div>  
                        </div>
                    </div>
                </div>

            </div>
            <br>
            <div class="row blue-info">
                پرفروشترین محصولات 
            </div>
            <div id="load-shop-index" class="row text-center load-new-product-index" onscroll="">
                <img src="img/Jumping letters.gif" alt="پرفروش ترین محصولات" height="42" width="140" />
                <br>
                <button class="btn btn-group-sm btn-danger" type="button" onclick="load_shop_index()">پرفروشترین محصولات</button>
                <?php //include_once './_php/load_new_product_index.php'; ?>
            </div>

            <?php //include_once './shop_product.php'; ?>

            <br><div class="row hr-black"></div>
            <div class="row moa-akh">
                <div class="col-md-1 float-992-right"></div>
                <div class="col-md-5 float-992-right text-right">
                    <div class="row">
                        <div class="col-md-12"><h2>معرفی</h2></div>
                        <hr><hr>
                        <?php
                        $table_intro = "cr_intro_news";
                        $fields_intro = "*";
                        $where_intro = "id>'0' and news_intro='معرفی'"; // and news_intro='خبر'
                        $order_intro = "id DESC";
                        $limit_intro = "0,4";
                        $intro = $dbclass->select($table_intro, $fields_intro, $where_intro, $order_intro, $limit_intro);

                        if (is_array($intro)) {
                            foreach ($intro as $row_intro) {
                                echo '
                                    <a title="'.$row_intro["title"].'" href="#"><div class="col-md-12">
                                        ' . $row_intro["title"] . '
                                        <img alt="'.$row_intro["title"].'" src="upload/50_50/' . $row_intro["photo"] . '" class="img-circle" height="50" width="50"/>
                                    </div></a>
                                        ';
                            }
                        }
                        ?>
                    </div>
                </div>
                <div class="col-md-5 float-992-right text-right">
                    <div class="row">
                        <div class="col-md-12"><h2>اخبار</h2></div>
                        <hr><hr>
                        <?php
                        $table_news = "cr_intro_news";
                        $fields_news = "*";
                        $where_news = "id>'0' and news_intro='خبر'"; // and news_intro='خبر'
                        $order_news = "id DESC";
                        $limit_news = "0,4";
                        $_news = $dbclass->select($table_news, $fields_news, $where_news, $order_news, $limit_news);

                        if (is_array($_news)) {
                            foreach ($_news as $row__news) {
                                echo '
                                    <a title="'.$row_intro["title"].'" href="#"><div class="col-md-12">
                                        ' . $row__news["title"] . '
                                        <img alt="'.$row_intro["title"].'" src="upload/50_50/' . $row__news["photo"] . '" class="img-circle" height="50" width="50"/>
                                    </div></a>
                                        ';
                            }
                        }
                        ?>
                    </div>
                </div>
                <div class="col-md-1 float-992-right"></div>
            </div>
            <div class="row hr-black"></div><br>
            <?php
            // put your code here
            include './footer.php';
            ?>
        </div>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
