<?php session_start();
include_once './DB/db_con.php';
$code_product = "";
if (isset($_GET["code"])) {
    $code_product = $_GET["code"];
} else {
    $code_product = "";
    header("location: products");
}
$code_product = str_replace("-", "#", $code_product); //str_replace("#", "-",$row_products["code_product"])

$table = "cr_product";
$fields = "*";
$where = "code_product='$code_product'";
$order = "id_product";
$limit = "1";
$produc = $dbclass->select_one($table, $fields, $where, $order, $limit);

$table_rate = "cr_rate";
$fields_rate = "*";
$where_rate = "code_product='$code_product'";
$order_rate = "id_rate";
$limit_rate = "0,1000000";
$produc_rate = $dbclass->select($table_rate, $fields_rate, $where_rate, $order_rate, $limit_rate);
$sum = 0;
if (is_array($produc_rate)) {
    foreach ($produc_rate as $row_rate) {
        $sum+=$row_rate["rate"];
    }
}
$rate_pro = ($sum / count($produc_rate));

$table_comment = "cr_comment";
$fields_comment = "*";
$where_comment = "code_product='$code_product' and ans_id_comment='0'";
$order_comment = "id_comment DESC";
$limit_comment = "0,15";
$produc_comment = $dbclass->select($table_comment, $fields_comment, $where_comment, $order_comment, $limit_comment);

$table_detail = "cr_detail_product";
$fields_detail = "*";
$where_detail = "code_product='$code_product'";
$order_detail = "id_detail";
$limit_detail = "0,1000";
$produc_detail = $dbclass->select($table_detail, $fields_detail, $where_detail, $order_detail, $limit_detail);
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <?php include_once './head.php'; ?>
        <title>کرنجال | <?php echo $produc["name_product_fa"]; ?></title>
        <meta NAME="DESCRIPTION" CONTENT="کرنجال فروش محصول <?php echo $produc["name_product_fa"]; ?> در کرنجال"/>
        <meta NAME="KEYWORDS" CONTENT="<?php echo $produc["name_product_fa"]; ?>،کرنجال،فروش محصول <?php echo $produc["name_product_fa"]; ?>،<?php echo $produc["name_product_fa"]; ?>"/>
    </head>
    <body>
        <div class="container-fluid">
            <?php
            // put your code here
            include './header.php';
            ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="row product">
                        <div class="col-md-5 col-sm-12 col-xs-12 pull-right">
                            <div class="img-product col-lg-10 col-sm-10 col-md-10 col-xs-10">

                                <div class="mag">
                                    <img alt="کرنجال <?php echo $produc["name_product_fa"]; ?> <?php echo $produc["name_product_en"]; ?>" width="100%" height="auto" data-toggle="magnify" src="upload/389_389/<?php echo $produc["photo_product"]; ?>" id="photo-product"/>
                                </div>
                            </div>
                            <div class="sidebar-slide col-lg-2 col-sm-2 col-md-2 col-xs-2">
                                <div class="row">
                                    <div class="col-lg-12 scrolltop text-center">
                                        <li class="glyphicon glyphicon-chevron-up font-sizing"></li>
                                    </div>
                                    <div class="col-lg-12 img-small-product">
                                        <div class="scroll-gallery-product">
                                            <?php
                                            $table_gallery = "cr_gallery";
                                            $fields_gallery = "photo_gallery";
                                            $where_gallery = "code_product='$code_product'";
                                            $order_gallery = "id_gallery";
                                            $limit_gallery = "15";
                                            $produc_gallery = $dbclass->select($table_gallery, $fields_gallery, $where_gallery, $order_gallery, $limit_gallery);
                                            if (is_array($produc_gallery)) {
                                                foreach ($produc_gallery as $row_gallery) {
                                                    echo '<a title="'.$produc["name_product_fa"].'" "'.$produc["name_product_en"].'" id="modal-970313-crenjal" href="#modal-container-970313-crenjal" role="button" class="btn" data-toggle="modal">'
                                                    . '<img alt="'.$produc["name_product_fa"].'" "'.$produc["name_product_en"].'" src="upload/74_74/' . $row_gallery["photo_gallery"] . '" width="100%" height="auto"/>'
                                                    . '</a>';
                                                }
                                            }
                                            ?>
                                        </div>
                                        <div class="modal fade in" id="modal-container-970313-crenjal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                            <div class="modal img-modal fade in">
                                                <div class="modal-dialog modal-lg" id="modal-images">
                                                    <div class="modal-content">
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-md-8 modal-image">
                                                                    <?php
                                                                    echo '
                                                                        <img class="img-responsive" src="upload/1349_790/' . $produc["photo_product"] . '" alt="'.$produc["name_product_fa"].'" "'.$produc["name_product_en"].'">
                                                                        ';
                                                                    if (is_array($produc_gallery)) {
                                                                        foreach ($produc_gallery as $row_gallery) {
                                                                            echo '
                                                                                <img alt="'.$produc["name_product_fa"].'" "'.$produc["name_product_en"].'" class="img-responsive hidden" src="upload/1349_790/' . $row_gallery["photo_gallery"] . '">
                                                                                ';
                                                                        }
                                                                    }
                                                                    ?>
                                                                    <a href="" class="img-modal-btn left"><i class="glyphicon glyphicon-chevron-left"></i></a>
                                                                    <a href="" class="img-modal-btn right"><i class="glyphicon glyphicon-chevron-right"></i></a>
                                                                </div>
                                                                <div class="col-md-4 modal-meta">
                                                                    <div class="modal-meta-top">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                        <br>
                                                                        <div class="img-poster clearfix text-right">
                                                                            <a title="<?php echo $produc["name_product_fa"] . " " .$produc["name_product_en"]; ?>" href="product/<?php echo str_replace("#", "-", $produc["code_product"]) . "/" . str_replace(" ", "-", $produc["name_product_fa"]) . "/" . str_replace(" ", "-", $produc["name_product_en"]); ?>">
                                                                                <img class="img-circle pull-right" src="upload/74_74/<?php echo $produc["photo_product"]; ?>"/>
                                                                            </a>
                                                                            <h3>
                                                                                <strong>
                                                                                    <a title="<?php echo $produc["name_product_fa"] . " " .$produc["name_product_en"]; ?>" style="margin-right: 3%;" href="product/<?php echo str_replace("#", "-", $produc["code_product"]) . "/" . str_replace(" ", "-", $produc["name_product_fa"]) . "/" . str_replace(" ", "-", $produc["name_product_en"]); ?>">
                                                                                        <?php echo $produc["name_product_fa"]; ?>
                                                                                    </a>
                                                                                </strong>
                                                                            </h3>
                                                                            <span>
                                                                                <div class="col-lg-8 col-xs-8 pull-right detail-product">
                                                                                    <div class="rate_product pull-right" id="" name="<?php echo $produc["code_product"]; ?>">
                                                                                        <div class="rate_star_on" id="" style="width: <?php echo $rate_pro * 20; ?>%;"></div>
                                                                                    </div>
                                                                                </div>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-meta-bottom">                                                                    
                                                                        <ul class="img-comment-list">
                                                                            
                                                                            <?php
                                                                            if(is_array($produc_detail)){
                                                                                foreach ($produc_detail as $value) {
                                                                                    echo '
                                                                                        <div class="row panel-default">
                                                                                            <div class="col-xs-12 pull-right text-right detail-product panel-heading" style="line-height: 212%">
                                                                                            '.$value["question"].'
                                                                                            </div>
                                                                                            <div class="col-xs-12 pull-right text-right detail-product" style="line-height: 212%">
                                                                                            '.$value["answer"].'
                                                                                            </div>
                                                                                        </div>
                                                                                        <hr>
                                                                                    ';
                                                                                }
                                                                            }
                                                                                                           /* if (is_array($produc_comment)) {
                                                                                foreach ($produc_comment as $row_comment) {
                                                                                    echo '
                                                                                        <li class="row">
                                                                                            <div class="comment-img pull-right col-xs-2">
                                                                                                <img src="img/logo.jpg">
                                                                                            </div>
                                                                                            <div class="comment-text pull-right text-right col-xs-10">
                                                                                                <strong><a href="">' . $row_comment["name_user"] . '</a></strong>
                                                                                                <span class="date sub-text">' . $row_comment["date_comment"] . '</span>
                                                                                                <p style="text-align: justify;">' . $row_comment["comment"] . '</p> 
                                                                                            </div>
                                                                                        </li>
                                                                                        ';
                                                                                }
                                                                            }*/
                                                                            ?>
                                                                        </ul>   
                                                                    <!--<input type="text" class="form-control" placeholder="Leave a commment.."/>-->
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.modal-content -->
                                                </div><!-- /.modal-dialog -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 scrollbottom text-center">
                                        <li class="glyphicon glyphicon-chevron-down font-sizing"></li>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7 col-sm-12 col-xs-12 pull-right">
                            <div class="row">
                                <div class="col-md-12 text-right">
                                    <a title="<?php echo $produc["name_product_fa"] . " " .$produc["name_product_en"]; ?>" href="product/<?php echo str_replace("#", "-", $produc["code_product"]) . "/" . str_replace(" ", "-", $produc["name_product_fa"]) . "/" . str_replace(" ", "-", $produc["name_product_en"]); ?>">
                                        <h2 title="<?php echo $produc["name_product_en"]; ?>"><?php echo $produc["name_product_fa"]; ?></h2>
                                    </a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12 text-right pull-right detail-product"><?php echo $produc["code_product"]; ?></div>
                                <div class="col-md-6 col-xs-12 text-left pull-right">
                                    <div class="row">
                                        <div class="col-lg-8 col-xs-8 pull-right detail-product">
                                            <div class="rate_product" id="rate-product1" name="<?php echo $produc["code_product"]; ?>">
                                                <div class="rate_star_on" id="rate-product1-on" data-original-title="<?php echo $rate_pro; ?>" style="width: <?php echo $rate_pro * 20; ?>%;"></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-xs-4 text-right detail-product pull-right" style="padding: 0">
                                            <?php
                                            $view = $produc["view_num"] + 1;
                                            $table_buy = "cr_product";
                                            $set = "rate_product='$rate_pro',view_num='$view'";
                                            $where_buy = "code_product='$code_product'";
                                            $updat = $dbclass->update($table_buy, $set, $where_buy);
                                            if (is_array($produc_rate)) {
                                                echo "امتیاز " . round($sum / count($produc_rate),1) . ", از " . count($produc_rate) . " رای";
                                            } else {
                                                echo "امتیاز " . $sum / count($produc_rate) . ", از " . 0 . " رای";
                                            }
                                            ?>

                                            <?php //echo $produc["rate_product"];   ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="hr-black"></div>
                            <div class="row">
                                <br>
                                <?php
                                $photo_color = split(",", $produc["color_photos"]);
                                if (is_array($photo_color)) {
                                    foreach ($photo_color as $col_photo) {
                                        if ($col_photo != "") {
                                            echo '<div class="col-xs-1 pull-right">
                                                <div class="thumbnail view-third">
                                                    <img src="upload/74_74/' . $col_photo . '" width="100%" height="auto" alt="کرنجال"/>
                                                </div>
                                            </div>';
                                        } else {
                                            echo '<div class="col-xs-1 pull-right">
                                                <div class="thumbnail view-third">
                                                    <img src="upload/74_74/' . $produc["photo_product"] . '" width="100%" height="auto" alt="کرنجال"/>
                                                </div>
                                            </div>';
                                        }
                                    }
                                } else {
                                    $photo = $produc["photo_product"];
                                    echo '<div class="col-xs-1 pull-right">
                                                <div class="thumbnail view-third">
                                                    <img src="upload/74_74/' . $produc["photo_product"] . '" width="100%" height="auto" alt="کرنجال"/>
                                                </div>
                                            </div>';
                                }
                                ?>
                            </div>
                            <br>
                            <div class="hr-black"></div>
                            <br>
                            <div class="row">
                                <div class="col-xs-2 pull-right detail-product text-right">
                                    رنگ *
                                </div>
                                <div class="col-xs-10 pull-right">
                                    <div class="styleds">
                                        <select id="color-pro">
                                            <?php
                                            $color = split("،", $produc["color_product"]);
                                            foreach ($color as $col) {
                                                echo '<option value=" ' . $col . '">
                                                ' . $col . '
                                            </option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="hr-black"></div>
                            <br>
                            <div class="row">
                                <div class="col-xs-4 pull-right detail-product text-right">
                                    <div class="pull-right">
                                        &nbsp;&nbsp;&nbsp;  تعداد * 
                                    </div>
                                    <div class="styleds">
                                        <select id="tedad-pro">
                                            <option value="1">
                                                1
                                            </option>
                                            <option value="2">
                                                2
                                            </option>
                                            <option value="3">
                                                3
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xs-4 pull-right detail-product text-right"></div>
                                <div class="col-xs-4 pull-right detail-product text-right">
                                    <button class="btn btn-add-product" onclick="buy_add_one('<?php echo $produc["code_product"]; ?>')">+ افزودن به سبد خرید </button>
                                </div>
                            </div>
                            <br>
                            <div class="hr-black"></div>
                            <br>
                            <div class="row">
                                <div class="col-xs-4 pull-right detail-product text-right">
                                    <div class="price">
                                        <h3 style="direction: rtl">

                                            <div class="ghimat-ghabl help-block">
                                                <?php echo $produc["main_price"] ?>
                                                تومان
                                            </div>
                                            <?php echo $produc["dis_price"] ?>
                                            تومان 
                                        </h3>
                                    </div>
                                </div>
                                <div class="col-xs-8 pull-right detail-product text-right">
                                    <!--<div class="row">
                                        <div class="col-xs-6 pull-right detail-product text-right"></div>
                                        <div class="col-xs-6 pull-right detail-product text-right">
                                            <button class="btn btn-add-product" onclick="<?php //echo $produc["code_product"];           ?>">مقایسه</button>
                                        </div>
                                        <br><hr>
                                        <div class="col-xs-12 pull-right detail-product text-right">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="row">
                                                        <div class="col-lg-10 text-right detail-product" id="ratinging">
                                                            <div class="pull-right star star-off" id="star-5" onclick="rate_product('<?php //echo $produc["code_product"];           ?>','5')" onmousemove="hover_rate(5)"></div>
                                                            <div class="pull-right star star-on" id="star-4" onclick="rate_product('<?php //echo $produc["code_product"];           ?>','4')" onmousemove="hover_rate(4)"></div>
                                                            <div class="pull-right star star-on" id="star-3" onclick="rate_product('<?php //echo $produc["code_product"];           ?>','3')" onmousemove="hover_rate(3)"></div>
                                                            <div class="pull-right star star-on" id="star-2" onclick="rate_product('<?php //echo $produc["code_product"];           ?>','2')" onmousemove="hover_rate(2)"></div>
                                                            <div class="pull-right star star-on" id="star-1" onclick="rate_product('<?php //echo $produc["code_product"];           ?>','1')" onmousemove="hover_rate(1)"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 detail-product">
                                                    امتیاز دادن به این محصول
                                                </div>
                                            </div>
                                        </div>

                                    </div>-->
                                </div>
                            </div>
                        </div>
                        <hr>
                    </div>
                    <!----------------------------------------------------------------------------------->
                    <?php
                    /*
                     * To change this license header, choose License Headers in Project Properties.
                     * To change this template file, choose Tools | Templates
                     * and open the template in the editor.
                     */
                    $group = $produc["group_product"];
                    $id_group = $produc["id_product"];
                    $table_moshabe = "cr_product";
                    $fields_moshabe = "*";
                    $where_moshabe = "group_product='$group' and id_product!='$id_group'";
                    $order_moshabe = "id_product DESC";
                    $limit_moshabe = "10";
                    $produc_moshabe = $dbclass->select($table_moshabe, $fields_moshabe, $where_moshabe, $order_moshabe, $limit_moshabe);
                    ?>
                    <div class="row blue-info">
                        محصولات مشابه
                    </div><br>
                    <div id="load-moshabeh-product-index" class="row text-center load-new-product-index" onscroll="">
                        <div class="row-pull">
                            <ul class="new-product-scroll" name="0" id="new-product-scroll">
                                <?php
                                if (is_array($produc_moshabe)) {
                                    foreach ($produc_moshabe as $row_new) {
                                        echo '<a title="'.$row_new["name_product_fa"].'" href="product/'.str_replace("#", "-",$row_new["code_product"])."/".str_replace(" ", "-", $row_new["name_product_fa"])."/".str_replace(" ", "-", $row_new["name_product_en"]).'">
                                                <div class="col-xs-2">
                                                    <img alt="'.$row_new["name_product_fa"].'" src="upload/240_238/'.$row_new["photo_product"].'" width="100%" />
                                                </div>
                                            </a>';
                                    }
                                }
                                ?>

                            </ul>
                        </div>
                        <a class="left carousel-control" data-slide="prev" onclick="left_new_product()"><i class="glyphicon glyphicon-chevron-left"></i></a>
                        <a class="right carousel-control" data-slide="next" onclick="right_new_product()"><i class="glyphicon glyphicon-chevron-right"></i></a>
                    </div>
                    <!----------------------------------------------------------------------------------->

                    <div class="row bg-white">
                        <div class="col-md-12">
                            <div class="accordion" id="accordion2">
                                <div class="accordion-group">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
                                            <div class="panel-heading">
                                                <h3 class="panel-title">
                                                    <div class="pull-left arow-bottom"></div>
                                                    <div class="pull-right"> توضیحات محصول «</div>
                                                </h3>
                                            </div>
                                        </a>
                                    </div>
                                    <div id="collapseOne" class="accordion-body collapse in">
                                        <div class="panel-body text-right detail-product">  <br>
<?php echo $produc["detail_product"]; ?>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="accordion-group">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
                                            <div class="panel-heading">
                                                <h3 class="panel-title">                                                    
                                                    <div class="pull-left arow-bottom"></div>
                                                    <div class="pull-right"> مشخصات کامل محصول «</div>
                                                </h3>
                                            </div>
                                        </a>
                                    </div>
                                    <div id="collapseTwo" class="accordion-body collapse in">
                                        <div class="panel-body">
                                            <?php
                                            if(is_array($produc_detail)){
                                                foreach ($produc_detail as $value) {
                                                    echo '
                                                        <div class="row panel-default">
                                                            <div class="col-md-3 col-xs-12 pull-right text-right detail-product panel-heading" style="line-height: 212%">
                                                            '.$value["question"].'
                                                            </div>
                                                            <div class="col-md-9 col-xs-12 pull-right text-right detail-product" style="line-height: 212%">
                                                            '.$value["answer"].'
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    ';
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="accordion-group">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
                                            <div class="panel-heading">
                                                <h3 class="panel-title">
                                                    <div class="pull-left arow-bottom"></div>
                                                    <div class="pull-right"> نظرات کاربران «</div>                                                    
                                                </h3>
                                            </div>
                                        </a>
                                    </div>
                                    <div id="collapseThree" class="accordion-body collapse in">
                                        <div class="panel-body">
                                            <div class="row insert-comment">
                                                <?php
                                                if (isset($_COOKIE["email"])) {
                                                    ?>
                                                    <form class="form-horizontal">
                                                        <div class="form-group">
                                                            <label for="inputEmail3" class="col-sm-2 control-label"></label>
                                                            <div class="col-sm-8">
                                                                <textarea class="form-control" id="txt-comment"></textarea>
                                                            </div>
                                                            <label for="inputEmail3" class="col-sm-2 control-label"></label>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-sm-offset-2 col-sm-10">
                                                                <button type="button" class="btn btn-default" onclick="comment('<?php echo $produc["code_product"]; ?>', '0')">ثبت نظر</button>
                                                            </div>
                                                        </div>
                                                    </form>
<?php } ?>
                                            </div>
                                            <div class="comment-append">

                                            </div>
                                            <?php
                                            if (is_array($produc_comment)) {
                                                foreach ($produc_comment as $row_comment) {
                                                    echo '<div class="row comments">
                                                <div class="col-xs-2 pull-right text-center">
                                                    <i class="glyphicon glyphicon-user" style="font-size:50px"></i>
                                                    
                                                    <p>
                                                    <div class="text-center btn user-comment">
                                                        ' . $row_comment["name_user"] . '
                                                    </div>
                                                    </p>
                                                </div>
                                                <div class="col-xs-8 coment pull-right">
                                                    <div class="row">
                                                        <div class="col-xs-12 pull-right">
                                                            <div class="row">
                                                                <div class="col-xs-6 pull-left text-left">

                                                                </div>
                                                                <div class="col-xs-6 pull-right text-right date-comment">
                                                                    ' . $row_comment["date_comment"] . '
                                                                </div>
                                                            </div>
                                                            <p dir="rtl">
                                                                ' . $row_comment["comment"] . '
                                                            </p>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-xs-4 pull-left text-left">
                                                                <button type="button" class="btn btn-add-product" onclick="add_comment_zir(\'' . $row_comment["id_comment"] . '\',\'' . $code_product . '\')">پاسخ به این پرسش</button>
                                                            </div>
                                                            <div class="col-xs-8 pull-right text-right date-comment">

                                                            </div>
                                                        </div>
                                                        
                                                    <div id="' . $row_comment["id_comment"] . '"></div>
                                                    ';
                                                    $id_comm = $row_comment["id_comment"];
                                                    $table_comment_zir = "cr_comment";
                                                    $fields_comment_zir = "*";
                                                    $where_comment_zir = "code_product='$code_product' and ans_id_comment='$id_comm'";
                                                    $order_comment_zir = "id_comment";
                                                    $limit_comment_zir = "0,15";
                                                    $produc_comment_zir = $dbclass->select($table_comment_zir, $fields_comment_zir, $where_comment_zir, $order_comment_zir, $limit_comment_zir);
                                                    if (is_array($produc_comment_zir)) {
                                                        foreach ($produc_comment_zir as $row_comment_zir) {

                                                            echo '<hr><div class="row">
                                                                    <div class="col-xs-1 pull-right"></div>
                                                                    <div class="col-xs-1 pull-right text-center btn">
                                                                    ' . $row_comment_zir["name_user"] . '
                                                                    </div>
                                                                    <div class="col-xs-8 pull-right text-right">
                                                                        <div class="row">
                                                                            <div class="col-xs-6 pull-left text-left">

                                                                            </div>
                                                                            <div class="col-xs-6 pull-right text-left date-comment">
                                                                                ' . $row_comment_zir["date_comment"] . '
                                                                            </div>
                                                                        </div>
                                                                        <p dir="rtl">
                                                                            ' . $row_comment_zir["comment"] . '
                                                                        </p>
                                                                    </div>
                                                                </div>';
                                                        }
                                                    }

                                                    echo '</div>
                                                </div>
                                                <div class="col-xs-2 pull-right"></div>
                                            </div><hr>';
                                                }
                                            } else {
                                                echo '
                                                <div class="row one-search empty-buy">
                                                هیچ نظری ثبت نگردیده است، 
                                                اولین نفری باشید که نظر خود را وارد میکنید
                                            </div>
                                                ';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <?php
// put your code here
            include './footer.php';
            ?>

        </div>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
