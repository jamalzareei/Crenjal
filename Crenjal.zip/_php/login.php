<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include_once '../DB/db_con.php';
if (isset($_POST["email_login"]) && isset($_POST["password_login"])) {
    $email = $dbclass->hacking($_POST["email_login"]);
    $password = $dbclass->hacking(md5($_POST["password_login"]));
    $table = "cr_register";
    $fields = "email,password";
    $where = "email='$email' and password='$password' and active_user='1'";
    $order = "email";
    $limit = "1";
    $url=$_SERVER["HTTP_REFERRER"];
    $user = $dbclass->select($table, $fields, $where, $order, $limit);
    if(is_array($user)){
        if (isset($_COOKIE["browser"])) {
            $browser=$_COOKIE["browser"];
            $browser_set="";
            $table_up="cr_shop";
            $where_up="cookie='$browser' and (email='info@crenjal.com' or email='$email')";
            $set_up = "email='$email' , cookie='$browser_set'";
            $updat_up = $dbclass->update($table_up, $set_up, $where_up);
            setcookie("browser", "", time()-1,"/");
        }
        setcookie("email",$email,time()+30*3600*30,"/");
        //header("location: ".$url);
        header("location: ".$_SERVER['HTTP_REFERER']);
    }  else {
        //header("location: ?login=error");
        //header("location: ".$_SERVER['HTTP_REFERER']."?login=error");
        header("location: ../result?login=error");
    }
}