<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
include_once '../DB/db_con.php';

if (isset($_POST["code_product"])) {
    $code_product =  trim($_POST["code_product"]);
    $slice="";
    if(isset($_SESSION["compare"])){
        $slice=split("code_product='$code_product'", $_SESSION["compare"]);
        if(count($slice)<2 && $_SESSION["compare"]!=" "){
            $_SESSION["compare"].=" or code_product='$code_product'";
        }
    }  else {
        $_SESSION["compare"]="code_product='$code_product'";
    }
    $five=split("or", $_SESSION["compare"]);
    if(count($slice)<2 && count($five)<=5){
    
        $table = "cr_product";
        $fields = "*";
        $where = $_SESSION["compare"];//"code_product='$code_product'";
        $order = "code_product";
        $limit = "0,5";
        $select = $dbclass->select($table, $fields, $where, $order, $limit);

        if (is_array($select)) {
            foreach ($select as $value_compare) {
                echo '<div class="row one-search num-compare-' . $value_compare["id_product"] . '" id="num-compare-' . $value_compare["id_product"] . '">
                                                                    <div class="col-xs-3 pull-right text-center">
                                                                        <img src="upload/50_50/'.$value_compare["photo_product"].'" class="img-circle img-searcher" width="50" height="50"/>
                                                                    </div>
                                                                    <div class="col-xs-6 pull-right text-right">
                                                                        <h4>'.$value_compare["name_product_fa"].'</h4>
                                                                        '.$value_compare["gender_product"].' - '.$value_compare["group_product"].'
                                                                    </div>
                                                                    <div class="col-xs-3 pull-right text-center price-search">
                                                                        <br>
                                                                        <label class="label label-danger" onclick="delete_compare(\'num-compare-' . $value_compare["id_product"] . '\',\'' . $value_compare["code_product"] . '\')">x<label>
                                                                    </div>
                                                                </div>';
            }
        } 
        else {
            echo 'not';
        }
    }  else {
        echo 'not1';
    }
} else {
    echo 'notsss';
}