<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include_once '../DB/db_con.php';
if(isset($_POST["id_shop"])){
    $id_shop=$_POST["id_shop"];
    $table="cr_shop";
    //$fields="*";
    $where="id_shop='$id_shop'";
    
    $delete=$dbclass->delete($table,$where);
    echo "deleted";
}