<?php
//session_start();
//$_SESSION["compare"]="code_product='crn#4545' or code_product='crn#615' or code_product='crn#415' or code_product='crn#515'";
include_once './DB/db_con.php';

function clientIP() {
    static $_list = array('REMOTE_ADDR', 'HTTP_CLIENT_IP', 'CLIENT_IP', 'HTTP_X_REAL_IP', 'HTTP_PROXY_CONNECTION', 'HTTP_FORWARDED', 'HTTP_CF_CONNECTING_IP', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_X_FORWARDED', 'HTTP_X_FORWARDED_HOST', 'HTTP_X_FORWARDED_SERVER', 'FORWARDED_FOR_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED_FOR_IP', 'HTTP_X_FORWARDED_FOR', 'FORWARDED', 'X_FORWARDED_FOR', 'FORWARDED_FOR', 'X_FORWARDED', 'HTTP_VIA', 'VIA');

    foreach ($_list as $_value) {
        if (isset($_SERVER[$_value]))
            return $_SERVER[$_value];
        elseif (getenv($_value))
            return getenv($_value);
        elseif (isset($HTTP_SERVER_VARS[$_value]))
            return $HTTP_SERVER_VARS[$_value];
        elseif (@apache_getenv($_value, TRUE))
            return apache_getenv($_value, TRUE);
        elseif (isset($_ENV[$_value]))
            return $_ENV[$_value];
        else
            continue;
    }

    return FALSE;
}
?>
<div class="row color-white" id="menu-full">
    <div class="col-md-3 visible-lg visible-md" id="logo">
        <a title="crnejal | کرنجال فروشگاه اینترنتی" href="#"><img src="img/logo.jpg" class="img-circle" width="100%" height="80" alt="crnejal | کرنجال فروشگاه اینترنتی"/></a>
    </div>
    <div class="col-md-9" id="menus">

        <div class="row">
            <div class="col-md-12 pull-right" id="sosial-search-reg">
                <nav class="navbar navbar-default navbar-static-top" role="navigation">
                    <div class="row">
                        <!-- login register saban kharid -->
                        <div class="col-md-4 float-992-right" id="reg-log-buy">
                            <div class="row">
                                <?php
                                if (isset($_COOKIE["email"])) {
                                    ?>
                                    <div class="col-xs-4 div-loader-buy pull-right text-center">
                                        <a title="مقایسه محصولات در کرنجال" href="compare" class="loader-buy btn-sosi">
                                            <div class="col-xs-12 pull-right text-center menu-bar menu-bar-buy">
                                                <span class="menu-buy"></span>
                                                <label id="lbl-sabad" class="visible-lg lbls-menu">مقایسه</label>
                                                <label class="num_compare">
                                                <?php  
                                                if(isset($_SESSION["compare"])){
                                                    $table_compare = "cr_product";
                                                    $fields_compare = "*";
                                                    $where_compare = $_SESSION["compare"];
                                                    $order_compare = "id_product";
                                                    $limit_compare = "5";
                                                    //echo $_COOKIE["browser"];
                                                    $select_compare = $dbclass->select($table_compare, $fields_compare, $where_compare, $order_compare, $limit_compare);
                                                    if(is_array($select_compare)){
                                                        echo count($select_compare);
                                                    }  else {
                                                        echo '0';
                                                    }
                                                }  else {
                                                    echo '0';
                                                }
                                                ?>
                                                </label>
                                            </div>
                                        </a>
                                        
                                        <div class="load-buy" id="add-rows-compare">
                                            <?php
                                            if(isset($_SESSION["compare"])){
                                                $table_compare = "cr_product";
                                                $fields_compare = "*";
                                                $where_compare = $_SESSION["compare"];
                                                $order_compare = "id_product";
                                                $limit_compare = "5";
                                                //echo $_COOKIE["browser"];
                                                $select_compare = $dbclass->select($table_compare, $fields_compare, $where_compare, $order_compare, $limit_compare);
                                                
                                                if(is_array($select_compare)){
                                                    foreach ($select_compare as $value_compare) {
                                                        echo '<a href="product/'.str_replace("#", "-",$value_compare["code_product"])."/".str_replace(" ", "-", $value_compare["name_product_fa"])."/".str_replace(" ", "-", $value_compare["name_product_en"]).'">
                                                            <div class="row one-search num-compare-' . $value_compare["id_product"] . '" id="num-compare-' . $value_compare["id_product"] . '">
                                                                <div class="col-xs-3 pull-right text-center">
                                                                    <img src="upload/50_50/'.$value_compare["photo_product"].'" class="img-circle img-searcher" width="50" height="50"/>
                                                                </div>
                                                                <div class="col-xs-6 pull-right text-right">
                                                                    <h4>'.$value_compare["name_product_fa"].'</h4>
                                                                    '.$value_compare["gender_product"].' - '.$value_compare["group_product"].'
                                                                </div>
                                                                <div class="col-xs-3 pull-right text-center price-search">
                                                                    <br>
                                                                    <label class="label label-danger" onclick="delete_compare(\'num-compare-' . $value_compare["id_product"] . '\',\'' . $value_compare["code_product"] . '\')">x<label>
                                                                </div>
                                                            </div>
                                                            </a>';
                                                    }
                                                }
                                                    
                                                //echo $_SESSION["compare"];
                                            }  else {
                                                echo '<div class="row one-search empty-buy">
                                                        هیچ محصولی به مقایسه اضافه نکرده اید
                                                    </div>';
                                            }
                                            ?>
                                            <!--<div class="row one-search empty-buy">
                                                سبد خرید شما خالی می باشد
                                            </div>
                                            <div class="row one-search">
                                                <div class="col-xs-3 pull-right text-center">
                                                    <img src="img/Capture1.JPG" class="img-circle img-searcher" width="50" height="50"/>
                                                </div>
                                                <div class="col-xs-6 pull-right text-right">
                                                    <h4>jamal</h4>
                                                    tozihat mahsol
                                                </div>
                                                <div class="col-xs-3 pull-right text-center price-search">
                                                    ghimat<br>
                                                    x
                                                </div>
                                            </div>-->
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="col-xs-4 div-loader-buy pull-right text-center">
                                    <a title="سبر خرید کرنجال" href="card" class="loader-buy btn-sosi">
                                        <div class="col-xs-12 pull-right text-center menu-bar menu-bar-buy">
                                            <span class="menu-buy"></span>
                                            <label id="lbl-sabad" class="visible-lg lbls-menu">سبد خرید</label>
                                            <label class="num-buys"><?php
                                                $ip = clientIP();
                                                if (isset($_COOKIE["browser"]) && !isset($_COOKIE["email"])) {
                                                    $browser = $_COOKIE["browser"];
                                                    $table = "cr_shop";
                                                    $fields = "*";
                                                    $where = "cookie='$browser' and ip_user='$ip' and admin_active='0'";
                                                    $order = "id_shop";
                                                    $limit = "10";
                                                    //echo $_COOKIE["browser"];
                                                    $buy_added = $dbclass->select($table, $fields, $where, $order, $limit);
                                                    if (is_array($buy_added)) {
                                                        echo count($buy_added);
                                                    } else {
                                                        echo '0';
                                                    }
                                                } 
                                                else if(isset($_COOKIE["email"])){
                                                    $email_cook = $_COOKIE["email"];
                                                    $table = "cr_shop";
                                                    $fields = "*";
                                                    $where = "email='$email_cook' and admin_active='0'";
                                                    $order = "id_shop";
                                                    $limit = "10";
                                                    //echo $_COOKIE["browser"];
                                                    $buy_added = $dbclass->select($table, $fields, $where, $order, $limit);
                                                    if (is_array($buy_added)) {
                                                        echo count($buy_added);
                                                    } else {
                                                        echo '0';
                                                    }
                                                }else {
                                                    echo '0';
                                                }
                                                ?></label>
                                        </div>
                                    </a>
                                    <div class="load-buy" id="load-body-added">
                                        <?php
                                        if (isset($_COOKIE["browser"]) && !isset($_COOKIE["email"])) {
                                            $browser = $_COOKIE["browser"];
                                            $table = "cr_shop";
                                            $fields = "*";
                                            $where = "cookie='$browser' and ip_user='$ip' and admin_active='0'";
                                            $order = "id_shop";
                                            $limit = "10";
                                            $buy_added = $dbclass->select($table, $fields, $where, $order, $limit);
                                            if (is_array($buy_added)) {
                                                foreach ($buy_added as $row_buy) {
                                                    echo '<a href="product/'.str_replace("#", "-",$row_buy["code_product"])."/".str_replace(" ", "-", $row_buy["name_product"])."/".str_replace(" ", "-", $row_buy["name_product"]).'">
                                                            <div class="row one-search" id="num-buy-' . $row_buy["id_product"] . '">
                                                        <div class="col-xs-3 pull-right text-center">
                                                            <img src="upload/50_50/' . $row_buy["photo_product"] . '" class="img-circle img-searcher" width="50" height="50"/>
                                                        </div>
                                                        <div class="col-xs-6 pull-right text-right">
                                                            <h4>' . $row_buy["name_product"] . '</h4>
                                                            ' . $row_buy["detail"] . '
                                                        </div>
                                                        <div class="col-xs-3 pull-right text-center price-search" onclick=(\'num-buy-' . $row_buy["id_product"] . '\')>
                                                            ' . $row_buy["price_product"] . '<br>
                                                            <label class="label label-danger" onclick="delet_buy_row(\'num-buy-' . $row_buy["id_product"] . '\',\'' . $row_buy["id_product"] . '\')">x<label>
                                                        </div>
                                                    </div>
                                                    </a>';
                                                }
                                            } else {
                                                echo '<div class="row one-search empty-buy" id="deleted_buy_div">
                                                    سبد خرید شما خالی می باشد
                                                </div>';
                                            }
                                        }elseif (isset($_COOKIE["email"])) {
                                            $email_cook_buy = $_COOKIE["email"];
                                            $table = "cr_shop";
                                            $fields = "*";
                                            $where = "email='$email_cook_buy' and admin_active='0'";
                                            $order = "id_shop";
                                            $limit = "10";
                                            $buy_added = $dbclass->select($table, $fields, $where, $order, $limit);
                                            if (is_array($buy_added)) {
                                                foreach ($buy_added as $row_buy) {
                                                    echo '<a href="product/'.str_replace("#", "-",$row_buy["code_product"])."/".str_replace(" ", "-", $row_buy["name_product"])."/".str_replace(" ", "-", $row_buy["name_product"]).'">
                                                            <div class="row one-search" id="num-buy-' . $row_buy["id_shop"] . '">
                                                        <div class="col-xs-3 pull-right text-center">
                                                            <img src="upload/50_50/' . $row_buy["photo_product"] . '" class="img-circle img-searcher" width="50" height="50"/>
                                                        </div>
                                                        <div class="col-xs-6 pull-right text-right">
                                                            <h4>' . $row_buy["name_product"] . '</h4>
                                                            ' . $row_buy["detail"] . '
                                                        </div>
                                                        <div class="col-xs-3 pull-right text-center price-search" onclick=(\'num-buy-' . $row_buy["id_product"] . '\')>
                                                            ' . $row_buy["price_product"] . '<br>
                                                            <label class="label label-danger" onclick="delet_buy_row(\'num-buy-' . $row_buy["id_shop"] . '\',\'' . $row_buy["id_shop"] . '\')">x<label>
                                                        </div>
                                                    </div>';
                                                }
                                            } else {
                                                echo '<div class="row one-search empty-buy" id="deleted_buy_div">
                                                    سبد خرید شما خالی می باشد
                                                </div>';
                                            }
                                        } else {
                                            echo '<div class="row one-search empty-buy" id="deleted_buy_div">
                                                    سبد خرید شما خالی می باشد
                                                </div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                                <?php
                                if (!isset($_COOKIE["email"])) {
                                    ?>
                                    <div class="col-xs-4 pull-right text-center menu-bar menu-bar-login">
                                        <a title="ورود به کرنجال" id="modal-435492" href="#modal-container-435492" role="button" class="btn btn-sosi col-md-12" data-toggle="modal">
                                            
                                            <span class="menu-login"></span>
                                            <label id="lbl-login" class="visible-lg lbls-menu">
                                                ورود
                                            </label>
                                        </a>
                                    </div>
                                    <div class="col-xs-4 pull-right text-center menu-bar menu-bar-register">
                                        <a title="ثبت نام در کرنجال" href="register" class="btn btn-sosi col-md-12">
                                            <span class="menu-register"></span>
                                            <label id="lbl-register" class="visible-lg lbls-menu">ثبت نام</label>
                                        </a>
                                    </div>
                                    <?php
                                } 
                                else {
                                    ?>
                                    <div class="col-xs-4 div-loader-buy pull-right text-center menu-bar menu-bar-login-in">
                                        <a title="فروشگاه اینترنتی صنایع دستی کرنجال" aria-expanded="true" href="#" class="dropdown-toggle col-md-12 padding-zero" data-toggle="dropdown">
                                            <span class="menu-login-in welcom-span" id="welcom-span"></span>
                                            <label class="lbls-menu lbl-login-in visible-lg">خوش امدید</label>                                            
                                            <b class="caret"></b></a>
                                        <ul class="dropdown-menu text-right">
                                            <li><a title="سبد خرید کرنجال" href="card">سبد خرید</a></li>
                                            <li><a title="پروفایل کاربران کرنجال" href="profile">پروفایل</a></li>
                                            <li class="divider"></li>
                                            <li><a title="فروشگاه اینترنتی کرنجال" href="_php/logout.php">خروج</a></li>
                                        </ul>

                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>

                        <!-- serach -->
                        <div class="col-md-6 float-992-right" id="search-form">
                            <form class="" id="search">
                                <div class="form-group form-searcher">
                                    <input type="search" id="txt_search" class="form-control search-auto glyphicon-search" onfocus="load_div_searcher_1()" onkeyup="load_search()" placeholder="... محصول مورد نظرتان را جستجو نمایید" />
                                    <div class="load-search">
                                        
                                    </div>
                                </div> 
                            </form>
                        </div>

                        <!-- shabake haye ejtemaei -->
                        <div class="col-md-2 float-992-right div-sosial" id="sosial">
                            <div class="row">
                                <div class="col-sm-3 pull-right text-center menu-bar-sosial menu-bar-facebook">
                                    <a title="فیس بوک کرنجال" href=""><span class="menu-facebook"></span></a>
                                </div>
                                <div class="col-sm-3 pull-right text-center menu-bar-sosial menu-bar-instagram">
                                    <a title="اینستاگرام کرنجال" href=""><span class="menu-instagram"></span></a>
                                </div>
                                <div class="col-sm-3 pull-right text-center menu-bar-sosial menu-bar-telegram">
                                    <a title="تلگرام کرنجال" href=""><span class="menu-telegram"></span></a>
                                </div>
                                <div class="col-sm-3 pull-right text-center menu-bar-sosial menu-bar-google+">
                                    <a title="گوگل پلاس کرنجال" href=""><span class="menu-google"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>

            <div class="col-md-12 pull-right" id="menu-list">
                <nav class="navbar navbar-default navbar-static-top zindex-search" role="navigation">
                    <div class="navbar-header">

                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
                        </button> <a title="فروشگاه صنایع دستی کرنجال" class="navbar-brand" href="">Crenjal</a>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <div class="responsive-menu">
                            <ul class="">
                                <li>
                                    <a title="محصولات پوشاک کرنجال" href="products/#/group1_1-poshak" class="ahref">پوشاک</a>
                                    <ul class="menu-navbar">
                                        <div class="row">
                                            <div class="col-md-4 pull-right">
                                                <a title="محصولات پوشاک کرنجال" href=""><h3 class="divider">آقایان</h3></a>
                                                <div class="hr-black"></div>
                                                <ul class="ul-zir-menus">
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-4 pull-right">
                                                <a title="محصولات پوشاک کرنجال" href=""><h3 class="divider">بانوان</h3></a>
                                                <div class="hr-black"></div>
                                                <ul class="ul-zir-menus">
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات پوشاک کرنجال" href="">jamal</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-4 pull-right">
                                                <div class="thumbnail">
                                                    
                                                </div>
                                            </div>

                                        </div>
                                    </ul>
                                    <div class="arrow-menu-bar"></div>
                                </li>
                                <li>
                                    <a title="محصولات کیف و کمربند کرنجال" href="products/#/group4_1-kif-kamarband" class="ahref">کیف و کمر بند</a>
                                    <ul class="menu-navbar">
                                        <div class="row">
                                            <div class="col-md-4 pull-right">
                                                <a title="محصولات کیف و کمربند کرنجال" href=""><h3 class="divider">آقایان</h3></a>
                                                <div class="hr-black"></div>
                                                <ul class="ul-zir-menus">
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-4 pull-right">
                                                <a title="محصولات کیف و کمربند کرنجال" href=""><h3 class="divider">بانوان</h3></a>
                                                <div class="hr-black"></div>
                                                <ul class="ul-zir-menus">
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات کیف و کمربند کرنجال" href="">jamal</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-4 pull-right">

                                            </div>

                                        </div>
                                    </ul>
                                    <div class="arrow-menu-bar"></div>
                                </li>
                                <li>
                                    <a title="محصولات دکوراتیو کرنجال" href="products/#/group2_1-dekorative" class="ahref">دکوراتیو</a>
                                    <div class="menu-navbar">
                                        <div class="row">
                                            <div class="col-md-4 pull-right">
                                                <ul class="ul-zir-menus">
                                                    <li><a title="محصولات دکوراتیو کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات دکوراتیو کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات دکوراتیو کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات دکوراتیو کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات دکوراتیو کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات دکوراتیو کرنجال" href="">jamal</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-4 pull-right">
                                            </div>
                                            <div class="col-md-4 pull-right">

                                            </div>

                                        </div>
                                    </div>
                                    <div class="arrow-menu-bar"></div>
                                </li>
                                <li>
                                    <a title="محصولات زیوآلات کرنجال" href="products/#//group3_1-zivaralat" class="ahref">زیورآلات</a>
                                    <div class="menu-navbar">

                                        <div class="row">
                                            <div class="col-md-4 pull-right">
                                                <ul class="ul-zir-menus">
                                                    <li><a title="محصولات زیوآلات کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات زیوآلات کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات زیوآلات کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات زیوآلات کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات زیوآلات کرنجال" href="">jamal</a></li>
                                                    <li><a title="محصولات زیوآلات کرنجال" href="">jamal</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-4 pull-right">
                                            </div>
                                            <div class="col-md-4 pull-right">

                                            </div>

                                        </div>

                                    </div>
                                    <div class="arrow-menu-bar"></div>
                                </li>
                            </ul>
                        </div>
                        <!--/////////////////////////////////-->

                        <!--
                                            <div class="moblie-menu">
                                            <ul class="nav navbar-nav navbar-right">
                                                <li class="dropdown">
                                                    <a aria-expanded="false" href="#" class="dropdown-toggle" data-toggle="dropdown">محصولات چرم </a>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="#">محصولات چرم</a></li>
                                                        <li><a href="#">Another action</a></li>
                                                        <li><a href="#">Something else here</a></li>
                                                        <li class="divider"></li>
                                                        <li><a href="#">Separated link</a></li>
                                                        <li class="divider"></li>
                                                        <li><a href="#">One more separated link</a></li>
                                                    </ul>
                                                </li>
                                                
                                            </ul>
                                            <ul class="nav navbar-nav navbar-right">
                                                <li class="dropdown">
                                                    <a aria-expanded="false" href="#" class="dropdown-toggle" data-toggle="dropdown">محصولات برنز و مس </a>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="#">محصولات برنز و مس</a></li>
                                                        <li><a href="#">Another action</a></li>
                                                        <li><a href="#">Something else here</a></li>
                                                        <li class="divider"></li>
                                                        <li><a href="#">Separated link</a></li>
                                                        <li class="divider"></li>
                                                        <li><a href="#">One more separated link</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                            <ul class="nav navbar-nav navbar-right">
                                                
                                                <li class="dropdown">
                                                    <a aria-expanded="false" href="#" class="dropdown-toggle" data-toggle="dropdown">پوشاک </a>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="#">پوشاک</a></li>
                                                        <li><a href="#">Another action</a></li>
                                                        <li><a href="#">Something else here</a></li>
                                                        <li class="divider"></li>
                                                        <li><a href="#">Separated link</a></li>
                                                        <li class="divider"></li>
                                                        <li><a href="#">One more separated link</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                            <ul class="nav navbar-nav navbar-right">
                                                <li class="dropdown">
                                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">محصولات کاشی سنتی </a>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="#">محصولات کاشی سنتی</a></li>
                                                        <li><a href="#">Another action</a></li>
                                                        <li><a href="#">Something else here</a></li>
                                                        <li class="divider"></li>
                                                        <li><a href="#">Separated link</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                            <ul class="nav navbar-nav navbar-right">
                                                <li class="dropdown">
                                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">محصولات چوب </a>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="#">محصولات چوب</a></li>
                                                        <li><a href="#">Another action</a></li>
                                                        <li><a href="#">Something else here</a></li>
                                                        <li class="divider"></li>
                                                        <li><a href="#">Separated link</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                        
                        </div>-->
                        <!--/////////////////////////////-->
                    </div>

                </nav>
            </div>
        </div>
    </div>
</div>
<?php if (!isset($_COOKIE["email"]) && strstr($_SERVER['REQUEST_URI'],"result")!="result?login=error") { ?>
    <div class="modal fade" id="modal-container-435492" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">


        <div id="login-overlay" class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title pull-right" id="myModalLabel">ورود به کرنجال</h2>
                    <button type="button" class="close pull-left" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                </div><hr><br>
                <div class="modal-body">
                    <div class="row row-into-modal-body">
                        <div class="col-md-12 pull-right">
                            <div class="col-md-12">
                                <form id="loginForm" method="POST" action="_php/login.php" novalidate="novalidate">
                                    <div class="form-group email-login">
                                        <label for="username" class="col-sm-3 control-label pull-right">ایمیل</label>
                                        <div class="col-sm-9">
                                            <input class="form-control col-xs-8" id="username" name="email_login" value="" required="" title="لطفا ایمیل خود را وارد نمایید" placeholder="info@crenjal.com" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="password" class="col-sm-3 control-label pull-right">رمز عبور</label>
                                        <div class="col-sm-9">
                                            <input class="form-control col-xs-8" id="password" name="password_login" value="" required="" title="لطفا پسور خود را وارد نمایید" placeholder="*******" type="password">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-3"></div>
                                        <div class="col-sm-9">
                                            <div class="checkbox">
                                                <label for="checkbox-forget-password" class="check-fulling checkbox-forget-password">
                                                    <input type="checkbox" id="checkbox-forget-password" name="forget_password" class="regular-checkbox" onchange="" />
                                                    <label id="all-product-true" class="pull-right lbl-forget-password" for="checkbox-forget-password"></label>
                                                    <div class="pull-right">ذخیره رمز عبور</div>
                                                </label>
                                            </div>
                                        </div>
                                    </div><br>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <button type="submit" class="btn btn-success btn-block">ورود</button>
                                        </div>
                                        <div class="col-lg-8 forget-pass">
                                            <a title="فراموشی رمز عبور" href="result?password=forget" class="alert alert-info">
                                                <strong dir="rtl">
                                                    رمز عبور خود را فراموش کرده ام!
                                                </strong>
                                            </a>
                                        </div>
                                    </div>
                                    <hr>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-12 pull-right">
                            <a title="ثبت نام در کرنجال" href="register" class="alert alert-info register-none">ثبت نام نکرده ام! <strong>ثبت نام در کرنجال</strong></a>
                        </div>
                        <br><hr><br>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>