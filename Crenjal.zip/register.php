<?php session_start();
if(isset($_COOKIE["email"])){
    header("location: products");
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <?php include_once './head.php'; ?>
        <title>کرنجال | ثبت نام</title>
        <meta NAME="DESCRIPTION" CONTENT="ثبت نام کاربران در کرنجال"/>
        <meta NAME="KEYWORDS" CONTENT="گرنجال،ثبت نام در کرنجال،ثبت نام کاربران در کرنجال"/>
    </head>
    <body>
        <div class="container-fluid">
            <?php
            // put your code here
            include './header.php';
            ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="row product">
                        <div class="col-xs-12 text-center">
                            <h1>ثبت نام در کرن<span style="color:#A60EAE">جال</span></h1>
                        </div>
                        <br><hr><br>
                        <div class="col-md-6 pull-right" style="padding-right: 7%">
                            <?php if(isset($_GET["register"]) && $_GET["register"]=="done" && isset($_GET["email"]) && isset($_GET["your-code-register"])){ ?>
                            <div class="alert alert-dismissable alert-success text-right">
                                <button type="button" class="close pull-left" data-dismiss="alert" aria-hidden="true">×</button>
                                <h4>ثبت نام موفقیت آمیز</h4>
                                <div>لطفا ایمیل خود را بررسی کنید،مراحل ثبت نام را دنبال فرمایید</div>
                            </div>
                            <?php } ?>
                            <?php if(isset($_GET["register"]) && $_GET["register"]=="error" && isset($_GET["email"])){ ?>
                            <div class="alert alert-dismissable alert-danger text-right">
                                <button type="button" class="close pull-left" data-dismiss="alert" aria-hidden="true">×</button>
                                <h4>خطا در ثبت نام</h4>
                                <div>با این ایمیل کاربر دیگری ثبت نام کرده است، لطفااز صحت ایمیل خوداطمینان حاصل کرده و مجددا نلاش فرمایید </div>
                            </div>
                            <?php } ?>
                            <?php if(isset($_GET["register"]) && $_GET["register"]=="error" && isset($_GET["password"]) && $_GET["password"]=="error"){ ?>
                            <div class="alert alert-dismissable alert-danger text-right">
                                <button type="button" class="close pull-left" data-dismiss="alert" aria-hidden="true">×</button>
                                <h4>خطا در ثبت نام</h4>
                                <div>رمز عبور و تکرار ان با هم یکی نیستند لطفا مجددا تلاش فرمایید</div>
                            </div>
                            <?php } ?>
                            <?php if(isset($_GET["register"]) && $_GET["register"]=="not_active"){ ?>
                            <div class="alert alert-dismissable alert-danger text-right">
                                <button type="button" class="close pull-left" data-dismiss="alert" aria-hidden="true">×</button>
                                <h4>خطا در ثبت نام</h4>
                                <div>ایمیل شما فعال نشده است ، در صورتی که ایمیل فعال سازی را دریافت نکرده اید با مدیریت تماس بگیرید. (info@crenjal.com)</div>
                            </div>
                            <?php } ?>
                            <form class="form-horizontal well" role="form" action="_php/register.php" method="post">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <input class="form-control text-right" id="txt-fname" name="fname" placeholder="نام" type="text" required="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <input class="form-control text-right" id="txt-lname" name="lname" placeholder="نام خانوادگی" type="text" required="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <input class="form-control" id="txt-email" name="email" placeholder="ایمیل (info@crenjal.com)" type="email" required="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <input class="form-control" id="txt-password" name="password" placeholder="رمز عبور (*******)" type="password" required="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <input class="form-control" id="txt-re-password" name="re_password" placeholder="تکرار رمز عبور  (*******)" type="password" required="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <div class="checkbox">

                                            <label for="checkbox-save-password" class="check-fulling checkbox-forget-password">
                                                <input id="checkbox-save-password" class="regular-checkbox" onchange="" type="checkbox">
                                                <label id="all-product-true" class="pull-right" for="checkbox-save-password" style="margin-top: 6px;min-height: 10px"></label>
                                                <div class="pull-right">با ثبت نام در سایت شما با قوانین سایت موافقت کرده اید</div>
                                            </label>
                                            <p class="help-block"> </p>

                                        </div>
                                    </div>
                                    <div class="col-sm-2"></div>
                                </div>
                                <div class="form-group">
                                    <div class=" col-sm-6">
                                        <button type="submit" class="btn btn-add-product">ثبت نام در سایت</button>
                                    </div>
                                    <div class="col-sm-6"></div>
                                </div>
                            </form>

                        </div>
                        <div class="col-md-6 pull-right text-right" style="padding: 0 40px">

                            <h2 style="margin-top: 0;">مزایای ثبت نام در  <span class="text-crenjal">کرنجال</span></h2>
                            <ul class="list-unstyled">
                                <li><span class="fa fa-check text-crenjal"></span> سریع و راحت خرید کنید</li>
                                <li><span class="fa fa-check text-crenjal"></span> نظر خود را با دیگران به اشتراک بگذارید</li>
                                <li><span class="fa fa-check text-crenjal"></span> تخفیف ها و فروش ویژه ما را دریافت کنید</li>
                                <li><span class="fa fa-check text-crenjal"></span> خریدهای خود را مدیریت کنید</li>
                                <li><span class="fa fa-check text-crenjal"></span> از ما هدیه دریافت کنید<small>(برای مناسبت های مختلف)</small></li>
                                <!--<li><a href="/read-more/"><u>اطلاعات بیشتر</u></a></li>-->
                                <li></li>
                                <li></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <?php
            // put your code here
            include './footer.php';
            ?>

        </div>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
